<?php

// app/Http/Controllers/BlogController.php

namespace App\Http\Controllers;

use App\Models\Post;

class BlogController extends Controller
{
    public function index()
    {
        $posts = Post::latest()->paginate(6);
        return view('admin.blog.index', compact('posts'));
    }

    public function show(Post $post)
    {
        return view('admin.blog.show', compact('post'));
    }
}

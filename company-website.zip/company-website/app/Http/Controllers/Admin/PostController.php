<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Post;
use Illuminate\Support\Facades\Storage;

class PostController extends Controller
{
    // عرض جميع المقالات
    public function index()
    {
        $posts = Post::latest()->paginate(10);
        return view('admin.posts.index', compact('posts'));
    }

    // عرض نموذج إنشاء مقال
    public function create()
    {
        return view('admin.posts.create');
    }

    // حفظ مقال جديد
    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'author' => 'nullable|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('image')) {
            $data['image'] = $request->file('image')->store('uploads', 'public');
        }

        Post::create($data);

        return redirect()->route('admin.posts.index')->with('success', 'تم نشر المقالة بنجاح');
    }

    // عرض مقال محدد
    public function show(Post $post)
    {
        return view('admin.posts.show', compact('post'));
    }

    // نموذج تعديل مقال
    public function edit(Post $post)
    {
        return view('admin.posts.edit', compact('post'));
    }

    // تحديث مقال
    public function update(Request $request, Post $post)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'author' => 'nullable|string|max:255',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('image')) {
            // حذف الصورة القديمة لو موجودة
            if ($post->image) {
                Storage::disk('public')->delete($post->image);
            }

            $data['image'] = $request->file('image')->store('uploads', 'public');
        }

        $post->update($data);

        return redirect()->route('admin.posts.index')->with('success', 'تم تعديل المقالة بنجاح');
    }

    // حذف مقال
    public function destroy(Post $post)
    {
        if ($post->image) {
            Storage::disk('public')->delete($post->image);
        }

        $post->delete();

        return redirect()->route('admin.posts.index')->with('success', 'تم حذف المقالة بنجاح');
    }
}

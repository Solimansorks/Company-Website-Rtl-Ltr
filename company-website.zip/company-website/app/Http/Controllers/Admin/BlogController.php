<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Post;

class BlogController extends Controller
{
    public function index()
    {
      $posts = Post::latest()->get(); // اجلب كل المقالات
    return view('admin.dashboard', compact('posts'));
    }

    public function create()
    {
        return view('admin.blog.create');
    }

  public function store(Request $request)
{
    $data = $request->validate([
        'title' => 'required|string|max:255',
        'content' => 'required|string',
        'author' => 'nullable|string|max:255',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
    ]);

    if ($request->hasFile('image')) {
        $data['image'] = $request->file('image')->store('uploads', 'public');
    }

    Post::create($data);

    return redirect()->route('posts.index')->with('success', 'تم نشر المقالة بنجاح');
}
    public function edit(Blog $blog)
    {
        return view('admin.blog.edit', compact('blog'));
    }

    public function update(Request $request, Blog $blog)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required',
            'author' => 'nullable|string|max:100',
            'image' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('image')) {
            if ($blog->image) {
                Storage::disk('public')->delete($blog->image);
            }
            $data['image'] = $request->file('image')->store('blogs', 'public');
        }

        $blog->update($data);
        return redirect()->route('blog.index')->with('success', 'تم تعديل المقالة بنجاح.');
    }

    public function destroy(Blog $blog)
    {
        if ($blog->image) {
            Storage::disk('public')->delete($blog->image);
        }
        $blog->delete();
        return redirect()->route('blog.index')->with('success', 'تم حذف المقالة بنجاح.');
    }
       public function show($id)
    {
        $post = Post::findOrFail($id);
        return view('admin.blog.show', compact('post'));
    }
}


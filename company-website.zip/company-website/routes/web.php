<?php

use Illuminate\Support\Facades\Route;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\SubscriberController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\Admin\BlogController as AdminBlogController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Admin\PostController;


Route::group([
    'prefix' => LaravelLocalization::setLocale(),
    'middleware' => [
        'web',
        'localeSessionRedirect',
        'localizationRedirect',
        'localizationRoutes',
    ]
], function () {

    // ✅ Auth Routes
    Auth::routes();

    // ✅ Public Pages
    Route::get('/', fn () => view('pages.home'))->name('home');
    Route::get('/about', fn () => view('pages.about'))->name('about');
    Route::get('/services', fn () => view('pages.services'))->name('services');
    Route::get('/portfolio', fn () => view('pages.portfolio'))->name('portfolio');
    Route::get('/testimonials', fn () => view('pages.testimonials'))->name('testimonials');
    Route::get('/contact', [ContactController::class, 'index'])->name('contact');
    Route::post('/contact', [ContactController::class, 'submit'])->name('contact.submit');

    // ✅ Blog Page
    Route::get('/blog', [BlogController::class, 'index'])->name('blog');

    // ✅ Newsletter
    Route::post('/subscribe', [SubscriberController::class, 'store'])->name('subscribe');

    // ✅ Services - Custom Pages
    Route::get('/services/web', [ServiceController::class, 'web'])->name('services.web');
    Route::get('/services/mobile', [ServiceController::class, 'mobile'])->name('services.mobile');
    Route::get('/services/graphic', [ServiceController::class, 'graphic'])->name('services.graphic');
    Route::get('/services/visual', [ServiceController::class, 'visual'])->name('services.visual');
    Route::get('/services/social', [ServiceController::class, 'social'])->name('services.social');
    Route::get('/services/ecommerce', [ServiceController::class, 'ecommerce'])->name('services.ecommerce');
    Route::get('/services/{slug}', [ServiceController::class, 'show'])->name('services.show');

    // ✅ Admin Dashboard Routes
    Route::prefix('admin')->middleware('auth')->group(function () {

        // ✅ Dashboard Home (Displays Posts)
        Route::get('/', [AdminBlogController::class, 'index'])->name('admin.dashboard');

        // ✅ Static Pages in Admin
        Route::view('/about', 'admin.about.index')->name('admin.about');
        Route::view('/services', 'admin.services.index')->name('admin.services');
        Route::view('/portfolio', 'admin.portfolio.index')->name('admin.portfolio');
        Route::view('/testimonials', 'admin.testimonials.index')->name('admin.testimonials');
        Route::view('/contact', 'admin.contact.index')->name('admin.contact');
    Route::resource('posts', App\Http\Controllers\Admin\PostController::class);

        // ✅ Blog CRUD
        Route::resource('blogs', AdminBlogController::class);
    });
});


Route::get('/blog', [BlogController::class, 'index'])->name('blog.index');
Route::get('/blog/{post}', [BlogController::class, 'show'])->name('blog.show');

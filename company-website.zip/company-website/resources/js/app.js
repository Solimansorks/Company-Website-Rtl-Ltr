import './bootstrap';

import Alpine from 'alpinejs';
import AOS from 'aos';
import 'aos/dist/aos.css';
AOS.init();

window.Alpine = Alpine;

Alpine.start();

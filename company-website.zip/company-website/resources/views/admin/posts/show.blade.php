@extends('admin.layouts.app')

@section('content')
<div class="max-w-4xl mx-auto px-4 py-6">
    <h1 class="text-3xl font-bold mb-4">{{ $post->title }}</h1>

    @if($post->image)
        <img src="{{ asset('storage/' . $post->image) }}" alt="{{ $post->title }}" class="w-full h-64 object-cover rounded mb-6">
    @endif

    <p class="text-gray-700 mb-4 leading-relaxed">{{ $post->content }}</p>
    <p class="text-sm text-gray-500 mb-2">الكاتب: {{ $post->author ?? 'غير معروف' }}</p>

    <a href="{{ route('posts.index') }}" class="inline-block mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">الرجوع للقائمة</a>
</div>
@endsection

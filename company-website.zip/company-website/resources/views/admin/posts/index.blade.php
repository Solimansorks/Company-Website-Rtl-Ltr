@extends('admin.layouts.app')

@section('content')
<div class="max-w-7xl mx-auto px-4 py-6">
    <h1 class="text-3xl font-bold mb-6 text-center">قائمة المقالات</h1>

    @if(session('success'))
        <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <div class="text-right mb-4">
        <a href="{{ route('posts.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">إضافة مقالة جديدة</a>
    </div>

    @if($posts->count())
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach($posts as $post)
                <div class="bg-white rounded-lg shadow p-4">
                    @if($post->image)
                        <img src="{{ asset('storage/' . $post->image) }}" alt="{{ $post->title }}" class="w-full h-48 object-cover rounded mb-3">
                    @endif

                    <h2 class="text-xl font-bold mb-2">{{ $post->title }}</h2>
                    <p class="text-gray-700 mb-2">{{ Str::limit($post->content, 100) }}</p>
                    <p class="text-sm text-gray-500 mb-4">الكاتب: {{ $post->author ?? 'غير معروف' }}</p>

                    <div class="flex justify-between items-center">
                        <a href="{{ route('posts.show', $post->id) }}" class="text-blue-600 hover:underline">عرض</a>
                        <div class="flex space-x-2">
                            <a href="{{ route('posts.edit', $post->id) }}" class="text-yellow-600 hover:underline">تعديل</a>
                            <form action="{{ route('posts.destroy', $post->id) }}" method="POST" onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-600 hover:underline">حذف</button>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="mt-6">
            {{ $posts->links() }}
        </div>
    @else
        <p class="text-gray-600 text-center">لا توجد مقالات حالياً.</p>
    @endif
</div>
@endsection

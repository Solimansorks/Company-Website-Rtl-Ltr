<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - @yield('title', 'إدارة الموقع')</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@3.4.1/dist/tailwind.min.css" rel="stylesheet">
<link href="https://cdn.tailwindcss.com" rel="stylesheet">

</head>
<body class="bg-gray-100 text-gray-800 font-sans leading-normal tracking-wide">

    <div class="min-h-screen flex flex-col">
        <!-- Header -->
        <header class="bg-white shadow-md p-4">
            <div class="container mx-auto">
                <h1 class="text-xl font-bold text-blue-700">لوحة التحكم</h1>
            </div>
        </header>

        <!-- Content -->
        <main class="flex-grow container mx-auto px-4 py-6">
            @yield('content')
        </main>

        <!-- Footer -->
        <footer class="bg-white shadow-inner p-4 text-center text-sm text-gray-500">
            &copy; {{ date('Y') }} جميع الحقوق محفوظة.
        </footer>
    </div>
<script src="https://cdn.tailwindcss.com"></script>

</body>
</html>

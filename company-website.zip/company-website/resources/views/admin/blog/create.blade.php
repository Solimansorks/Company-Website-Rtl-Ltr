@extends('admin.layouts.app')

@section('content')
<div class="max-w-2xl mx-auto mt-10">
    <h2 class="text-2xl font-bold mb-4">إضافة مقالة</h2>

    @if (session('success'))
        <div class="bg-green-100 text-green-700 p-3 mb-4 rounded">{{ session('success') }}</div>
    @endif

    <form method="POST" action="{{ route('posts.store') }}" enctype="multipart/form-data" class="space-y-4">
        @csrf

        <div>
            <label>العنوان:</label>
            <input type="text" name="title" class="w-full border rounded p-2" required>
        </div>

        <div>
            <label>المحتوى:</label>
            <textarea name="content" rows="5" class="w-full border rounded p-2" required></textarea>
        </div>

        <div>
            <label>الناشر:</label>
            <input type="text" name="author" class="w-full border rounded p-2">
        </div>

        <div>
            <label>الصورة:</label>
            <input type="file" name="image" class="w-full border rounded p-2">
        </div>

        <div>
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">نشر المقالة</button>
        </div>
    </form>
</div>
@endsection

@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto py-10 px-4">
    <h1 class="text-4xl font-bold mb-6">{{ $post->title }}</h1>

    @if($post->image)
        <img src="{{ asset('storage/' . $post->image) }}" alt="{{ $post->title }}" class="w-full h-80 object-cover mb-6 rounded-lg">
    @endif

    @if($post->author)
        <p class="text-sm text-gray-500 mb-2">بواسطة: {{ $post->author }}</p>
    @endif

    <div class="prose max-w-none">
        {!! nl2br(e($post->content)) !!}
    </div>

    <div class="mt-8">
        <a href="{{ route('blog.index') }}" class="text-blue-600 hover:underline">← العودة إلى المدونة</a>
    </div>
</div>
@endsection

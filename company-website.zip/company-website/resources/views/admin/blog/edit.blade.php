@extends('admin.layouts.app')

@section('content')
<div class="max-w-3xl mx-auto py-8">
    <h2 class="text-3xl font-bold mb-6 text-center">تعديل المقالة</h2>

    @if ($errors->any())
        <div class="mb-4 p-4 bg-red-100 text-red-700 rounded">
            <ul class="list-disc list-inside">
                @foreach ($errors->all() as $error)
                    <li>• {{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('blogs.update', $blog->id) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
        @csrf
        @method('PUT')

        <div>
            <label class="block mb-1 font-semibold">عنوان المقالة</label>
            <input type="text" name="title" class="w-full border border-gray-300 p-3 rounded" value="{{ old('title', $blog->title) }}" required>
        </div>

        <div>
            <label class="block mb-1 font-semibold">المحتوى</label>
            <textarea name="content" rows="6" class="w-full border border-gray-300 p-3 rounded" required>{{ old('content', $blog->content) }}</textarea>
        </div>

        <div>
            <label class="block mb-1 font-semibold">الناشر (اختياري)</label>
            <input type="text" name="author" class="w-full border border-gray-300 p-3 rounded" value="{{ old('author', $blog->author) }}">
        </div>

        <div>
            <label class="block mb-1 font-semibold">الصورة الحالية</label>
            @if($blog->image)
                <img src="{{ asset('storage/blogs/' . $blog->image) }}" alt="Current Image" class="h-24 mb-2 rounded">
            @else
                <p class="text-sm text-gray-500">لا توجد صورة حالياً</p>
            @endif
            <input type="file" name="image" class="w-full border border-gray-300 p-2 rounded">
        </div>

        <div class="text-center">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded">
                تحديث المقالة
            </button>
        </div>
    </form>
</div>
@endsection

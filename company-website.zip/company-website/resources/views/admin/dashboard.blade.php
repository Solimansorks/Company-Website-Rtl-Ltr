{{-- resources/views/admin/dashboard.blade.php --}}
@extends('layouts.app')

@section('content')
<div class="container mx-auto p-4">
    <h1 class="text-3xl font-bold mb-6">لوحة التحكم</h1>

    {{-- زر إنشاء بوست جديد --}}
    <div class="flex justify-end mb-4">
        <a href="{{ route('blogs.create') }}"
           class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            إضافة بوست جديد
        </a>
    </div>

    {{-- جدول البوستات --}}
    <div class="bg-white shadow-md rounded overflow-x-auto">
        <table class="min-w-full">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-6 py-3 text-right text-sm font-medium text-gray-600">العنوان</th>
                    <th class="px-6 py-3 text-right text-sm font-medium text-gray-600">تاريخ النشر</th>
                    <th class="px-6 py-3 text-right text-sm font-medium text-gray-600">الإجراءات</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                @forelse($posts as $post)
                <tr>
                    <td class="px-6 py-4 text-right">{{ $post->title }}</td>
                    <td class="px-6 py-4 text-right">{{ $post->created_at->format('Y-m-d') }}</td>
                    <td class="px-6 py-4 text-right flex gap-2 justify-end">
                        <a href="{{ route('blogs.show', $post->id) }}"
                           class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-sm">
                            عرض
                        </a>
                        <a href="{{ route('blogs.edit', $post->id) }}"
                           class="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded text-sm">
                            تعديل
                        </a>
                        <form action="{{ route('blogs.destroy', $post->id) }}" method="POST"
                              onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                    class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm">
                                حذف
                            </button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="3" class="text-center py-4 text-gray-500">لا توجد بوستات حالياً</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection

@extends('layouts.app')

@section('title', __('Mobile App Development'))

@section('content')
<section class="bg-white py-20">
    <div class="container mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
        <div>
            <h1 class="text-4xl font-bold text-gray-800 mb-6">Mobile App Solutions</h1>
            <p class="text-gray-600 leading-relaxed mb-6">
                We build custom Android and iOS applications that deliver excellent performance and intuitive design. Whether it's a business app or an e-commerce platform, we have you covered.
            </p>
            <ul class="list-disc pl-6 text-gray-600 mb-6 space-y-2">
                <li>Flutter & React Native</li>
                <li>Play Store & App Store publishing</li>
                <li>Secure and scalable apps</li>
                <li>API integration & backend support</li>
            </ul>
            <a href="{{ route('contact') }}" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                Request a Quote
            </a>
        </div>
        <div>
            <img src="{{ asset('images/services/mobile-app.jpg') }}" alt="Mobile App Development" class="rounded-2xl shadow-lg w-full">
        </div>
    </div>
</section>
@endsection

@extends('layouts.app')

@section('title', __('Digital Marketing'))

@section('content')
<section class="bg-white py-20">
    <div class="container mx-auto px-4 grid md:grid-cols-2 gap-10 items-center">
        <div>
            <h1 class="text-4xl font-bold text-gray-800 mb-6">Digital Marketing Services</h1>
            <p class="text-gray-600 leading-relaxed mb-6">
                Let us grow your online presence with our expert digital marketing services. We provide SEO, social media management, paid campaigns, and email marketing strategies that convert.
            </p>
            <ul class="list-disc pl-6 text-gray-600 mb-6 space-y-2">
                <li>SEO optimization</li>
                <li>Social media ads & management</li>
                <li>Google Ads campaigns</li>
                <li>Email and content marketing</li>
            </ul>
            <a href="{{ route('contact') }}" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition">
                Boost My Business
            </a>
        </div>
        <div>
            <img src="{{ asset('images/services/digital-marketing.jpg') }}" alt="Digital Marketing" class="rounded-2xl shadow-lg w-full">
        </div>
    </div>
</section>
@endsection

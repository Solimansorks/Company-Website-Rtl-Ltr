@extends('layouts.app')

@section('content')
<section class="relative py-20 bg-gradient-to-br from-blue-50 to-white dark:from-gray-900 dark:to-gray-800">
    <div class="container mx-auto px-6">
        <div class="text-center mb-12">
            <h2 class="text-4xl font-extrabold text-gray-900 dark:text-white animate-fade-in-down">
                {{ __('contact.contact_title') }}
            </h2>
            <p class="mt-4 text-lg text-gray-600 dark:text-gray-300 animate-fade-in">
                {{ __('contact.contact_subtitle') }}
            </p>
        </div>

        <div class="grid md:grid-cols-2 gap-10 items-start">
            <!-- Contact Form -->
            <div class="bg-white dark:bg-gray-900 p-8 rounded-2xl shadow-xl animate-slide-in-left">
                <form method="POST" action="{{ route('contact.submit') }}" class="space-y-6">
                    @csrf
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">{{ __('contact.name') }}</label>
                        <input type="text" name="name" required class="w-full mt-1 p-3 rounded-lg border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">{{ __('contact.email') }}</label>
                        <input type="email" name="email" required class="w-full mt-1 p-3 rounded-lg border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">{{ __('contact.phone') }}</label>
                        <input type="text" name="phone" class="w-full mt-1 p-3 rounded-lg border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">{{ __('contact.message') }}</label>
                        <textarea name="message" rows="4" required class="w-full mt-1 p-3 rounded-lg border border-gray-300 dark:border-gray-700 dark:bg-gray-800 dark:text-white"></textarea>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white py-3 px-8 rounded-lg text-lg font-semibold transition transform hover:scale-105">
                            {{ __('contact.contact_button') }}
                        </button>
                    </div>
                </form>
            </div>

            <!-- Location Map -->
            <div class="animate-slide-in-right">
                <div class="overflow-hidden rounded-2xl shadow-lg">
                    <iframe class="w-full h-96" frameborder="0" style="border:0"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3454.123456!2d31.235711!3d30.044420!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1234567890abcdef!2sYour+Location!5e0!3m2!1sen!2seg!4v1600000000000" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
@keyframes fade-in {
    from { opacity: 0; }
    to { opacity: 1; }
}
.animate-fade-in {
    animation: fade-in 1s ease-out;
}
.animate-fade-in-down {
    animation: fade-in 1s ease-out;
    transform: translateY(-10px);
}
@keyframes slide-in-left {
    from { opacity: 0; transform: translateX(-50px); }
    to { opacity: 1; transform: translateX(0); }
}
.animate-slide-in-left {
    animation: slide-in-left 1s ease-out;
}
@keyframes slide-in-right {
    from { opacity: 0; transform: translateX(50px); }
    to { opacity: 1; transform: translateX(0); }
}
.animate-slide-in-right {
    animation: slide-in-right 1s ease-out;
}
</style>
@endsection

@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h2 class="text-center mb-4">Blog</h2>

    <div class="row">
        @forelse($posts as $post)
        <div class="col-md-4 mb-4">
            <div class="card h-100 shadow-sm">
                @if($post->image)
                <img src="{{ asset('storage/' . $post->image) }}" class="card-img-top" alt="{{ $post->title }}">
                @endif

                <div class="card-body d-flex flex-column">
                    <h5 class="card-title">{{ $post->title }}</h5>
                    <p class="card-text text-muted mb-2">
                        <small>By {{ $post->author ?? 'Unknown' }}</small>
                    </p>
                    <p class="card-text">{{ Str::limit(strip_tags($post->content), 100) }}</p>
                    <a href="#" class="btn btn-outline-primary mt-auto disabled">Read more</a>
                </div>
            </div>
        </div>
        @empty
        <div class="col-12">
            <p class="text-center">No blog posts available yet.</p>
        </div>
        @endforelse
    </div>
</div>
@endsection

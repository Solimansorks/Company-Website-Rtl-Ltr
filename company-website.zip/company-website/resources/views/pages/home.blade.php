@extends('layouts.app')

@section('content')
    <!-- Hero Section -->
<!-- Hero Section -->
<section class="relative">
    <div class="swiper mySwiper h-[90vh] w-full">
        <div class="swiper-wrapper">

            <!-- Slide 1 -->
            <div class="swiper-slide">
                <img src="{{ asset('/images/slides/slide3.jpg') }}" class="w-full h-full object-cover" alt="Slide 1">
            </div>

            <!-- Slide 2 -->
            <div class="swiper-slide">
                <img src="{{ asset('/images/slides/slide3.jpg') }}" class="w-full h-full object-cover" alt="Slide 2">
            </div>

            <!-- Slide 3 -->
            <div class="swiper-slide">
                <img src="{{ asset('images/slides/slide3.jpg') }}" class="w-full h-full object-cover" alt="Slide 3">
            </div>

        </div>

        <!-- نقاط التحكم -->
        <div class="swiper-pagination !bottom-4"></div>
    </div>
</section>

<!-- Swiper CDN -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<!-- Swiper Init -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        new Swiper(".mySwiper", {
            loop: true,
            autoplay: {
                delay: 4000,
                disableOnInteraction: false,
            },
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
        });
    });
</script>


<!-- من نحن -->
<section class="py-16 bg-gray-100" id="about">
    <div class="container mx-auto px-4 text-center {{ app()->getLocale() == 'ar' ? 'md:text-right' : 'md:text-left' }}">
        <div class="md:flex md:items-center {{ app()->getLocale() == 'ar' ? 'md:flex-row-reverse' : '' }} md:justify-between">
            
            <!-- Text -->
            <div class="md:w-1/2">
                <h2 class="text-3xl md:text-4xl font-bold mb-4 text-blue-800">
                    {{ __('about.title') }}
                </h2>
                <p class="text-gray-700 leading-loose text-lg mb-6">
                    {{ __('about.description') }}
                </p>

                <div class="grid grid-cols-2 gap-6 text-center {{ app()->getLocale() == 'ar' ? 'md:text-right' : 'md:text-left' }}">
                    <div>
                        <p class="text-3xl font-bold text-blue-600">+10</p>
                        <p class="text-gray-600">{{ __('about.years_experience') }}</p>
                    </div>
                    <div>
                        <p class="text-3xl font-bold text-blue-600">+120</p>
                        <p class="text-gray-600">{{ __('about.projects') }}</p>
                    </div>
                    <div>
                        <p class="text-3xl font-bold text-blue-600">+50</p>
                        <p class="text-gray-600">{{ __('about.clients') }}</p>
                    </div>
                    <div>
                        <p class="text-3xl font-bold text-blue-600">+15</p>
                        <p class="text-gray-600">{{ __('about.team') }}</p>
                    </div>
                </div>
            </div>

            <!-- Image -->
            <div class="md:w-1/2 mt-10 md:mt-0">
                <img src="{{ asset('images/slides/slide2.jpg') }}" alt="about us" class="rounded-lg shadow-lg mx-auto">
            </div>
        </div>
    </div>
</section>
<!-- من نحن نهايه  -->
<!-- خدماتنا -->
<section class="bg-gray-100 py-16">
    <div class="max-w-7xl mx-auto px-4">
        <h2 class="text-3xl font-bold mb-4 text-center text-blue-600 animate-fade-in">
            {{ __('services.our_services') }}
        </h2>
        <p class="text-gray-600 max-w-2xl text-center mx-auto mb-10 animate-fade-in">
            {{ __('services.intro') }}
        </p>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-10">
            @foreach(__('services.items') as $service)
                <div class="bg-white shadow-md hover:shadow-xl transition duration-300 rounded-xl p-6 flex items-start space-x-4 animate-slide-up">
                    <div class="text-blue-500 text-4xl">
                        {!! $service['icon'] !!}
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold mb-1 text-gray-800">
                            {{ $service['title'] }}
                        </h3>
                        <p class="text-gray-600 text-sm leading-relaxed">
                            {{ $service['description'] }}
                        </p>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
<!-- خدماتنا -->

<!-- Lucide Icons -->
<script type="module">
  import lucide from 'https://unpkg.com/lucide@latest/dist/esm/lucide.js';
  lucide.createIcons();
</script>

<!-- Optional: Animate.css (for fade-in animation) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<style>
    .animate-fade-in {
        animation: fadeInUp 0.7s ease-in-out;
    }
    @keyframes fadeInUp {
        0% { opacity: 0; transform: translateY(30px); }
        100% { opacity: 1; transform: translateY(0); }
    }
</style>


    <!-- Portfolio Section -->
    <!-- <section class="py-16 bg-white">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-3xl font-bold mb-4">{{ __('home.portfolio_title') }}</h2>
            <p class="text-lg text-gray-700 mb-10">{{ __('home.portfolio_subtitle') }}</p>
            <!-- Portfolio items go here -->
        </div>
    <!-- </section> --> 

    <!-- Testimonials Section -->
<section class="bg-gray-50 py-16">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-6 text-blue-600 animate-fade-in">
            {{ __('testimonials.title') }}
        </h2>
        <p class="text-gray-600 mb-12 max-w-2xl mx-auto animate-fade-in">
            {{ __('testimonials.subtitle') }}
        </p>

        <div class="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            @foreach(__('testimonials.items') as $testimonial)
                <div class="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition duration-300 animate-slide-up">
                    <div class="mb-4">
                        <svg class="w-10 h-10 text-blue-500 mx-auto" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M7 10c0 2.761-2.239 5-5 5v-2c1.657 0 3-1.343 3-3H3V6h4v4zm10 0c0 2.761-2.239 5-5 5v-2c1.657 0 3-1.343 3-3h-2V6h4v4z" />
                        </svg>
                    </div>
                    <p class="text-gray-700 italic mb-4">"{{ $testimonial['message'] }}"</p>
                    <h4 class="text-lg font-semibold text-blue-600">{{ $testimonial['name'] }}</h4>
                    <p class="text-sm text-gray-500">{{ $testimonial['position'] }}</p>
                </div>
            @endforeach
        </div>
    </div>
</section>


    <!-- Contact Section -->
    <section id="contact" class="py-16 bg-white">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-3xl font-bold mb-4">{{ __('home.contact_title') }}</h2>
            <p class="text-lg text-gray-700 mb-6">{{ __('home.contact_subtitle') }}</p>
            <a href="{{ route('contact') }}" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded">
                {{ __('home.contact_button') }}
            </a>
        </div>
    </section>
@endsection

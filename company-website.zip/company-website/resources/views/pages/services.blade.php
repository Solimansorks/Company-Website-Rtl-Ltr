@extends('layouts.app')

@section('title', __('services.page_title'))

@section('content')
<section class="bg-gray-100 py-16">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-4 text-blue-600 animate-fade-in">
            {{ __('services.our_services') }}
        </h2>
        <p class="text-gray-600 max-w-xl mx-auto mb-10 animate-fade-in">
            {{ __('services.intro') }}
        </p>

        <div class="grid gap-8 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            @foreach(__('services.items') as $service)
                <div class="bg-white rounded-xl shadow-md p-6 hover:shadow-xl transition duration-300 animate-slide-up text-start">
                    <div class="text-5xl mb-4 text-blue-500">
                        {!! $service['icon'] !!}
                    </div>
                    <h3 class="text-xl font-bold mb-2 text-gray-800">
                        {{ $service['title'] }}
                    </h3>
                    <p class="text-gray-600 text-sm leading-relaxed">
                        {{ $service['description'] }}
                    </p>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endsection

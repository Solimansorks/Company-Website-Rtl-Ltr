
@extends('layouts.app')

@section('title', __('Testimonials'))

@section('content')
    <div class="space-y-4">
        <h2 class="text-3xl font-bold text-blue-600">{{ __('What Our Clients Say') }}</h2>
        <p class="text-gray-700">
            {{ __('Read the experiences of our satisfied clients.') }}
        </p>
    </div>
@endsection

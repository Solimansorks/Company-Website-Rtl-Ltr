@extends('layouts.app')

@section('content')
    <!-- Hero Section -->
    <section class="relative bg-gray-900 text-white py-20">
        <div class="container mx-auto px-4 text-center">
            <h1 class="text-4xl font-bold mb-4">{{ __('home.hero_title') }}</h1>
            <p class="text-lg mb-6">{{ __('home.hero_subtitle') }}</p>
            <a href="#contact" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded">
                {{ __('home.hero_button') }}
            </a>
        </div>
    </section>

    <!-- About Section -->
    <section class="py-16 bg-white">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-3xl font-bold mb-4">{{ __('home.about_title') }}</h2>
            <p class="text-lg text-gray-700">{{ __('home.about_text') }}</p>
        </div>
    </section>

    <!-- Services Section -->
    <section class="py-16 bg-gray-100">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-3xl font-bold mb-10">{{ __('home.services_title') }}</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-white p-6 rounded shadow">
                    <h3 class="font-semibold text-xl">{{ __('home.services_web') }}</h3>
                </div>
                <div class="bg-white p-6 rounded shadow">
                    <h3 class="font-semibold text-xl">{{ __('home.services_mobile') }}</h3>
                </div>
                <div class="bg-white p-6 rounded shadow">
                    <h3 class="font-semibold text-xl">{{ __('home.services_graphic') }}</h3>
                </div>
                <div class="bg-white p-6 rounded shadow">
                    <h3 class="font-semibold text-xl">{{ __('home.services_visual') }}</h3>
                </div>
                <div class="bg-white p-6 rounded shadow">
                    <h3 class="font-semibold text-xl">{{ __('home.services_social') }}</h3>
                </div>
                <div class="bg-white p-6 rounded shadow">
                    <h3 class="font-semibold text-xl">{{ __('home.services_ecommerce') }}</h3>
                </div>
            </div>
        </div>
    </section>

    <!-- Portfolio Section -->
    <section class="py-16 bg-white">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-3xl font-bold mb-4">{{ __('home.portfolio_title') }}</h2>
            <p class="text-lg text-gray-700 mb-10">{{ __('home.portfolio_subtitle') }}</p>
            <!-- Portfolio items go here -->
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="py-16 bg-gray-100">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-3xl font-bold mb-4">{{ __('home.testimonials_title') }}</h2>
            <p class="text-lg text-gray-700 mb-10">{{ __('home.testimonials_subtitle') }}</p>
            <!-- Testimonials go here -->
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-16 bg-white">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-3xl font-bold mb-4">{{ __('home.contact_title') }}</h2>
            <p class="text-lg text-gray-700 mb-6">{{ __('home.contact_subtitle') }}</p>
            <a href="{{ route('contact') }}" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded">
                {{ __('home.contact_button') }}
            </a>
        </div>
    </section>
@endsection

<!-- resources/views/layouts/partials/hero-slider.blade.php -->

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

<div class="swiper mySwiper h-screen w-full">
  <div class="swiper-wrapper">
    @foreach(['slide1.jpg','slide2.jpg','slide3.jpg','slide4.jpg'] as $slide)
      <div class="swiper-slide bg-cover bg-center relative" style="background-image: url('{{ asset('images/slides/'.$slide) }}')">
        <div class="absolute inset-0 bg-black/60 flex items-center justify-center text-center">
          <h2 class="text-white text-4xl md:text-6xl font-bold">Your 3D Vision Realized</h2>
        </div>
      </div>
    @endforeach
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
  const swiper = new Swiper('.mySwiper', {
    direction: 'vertical',
    loop: true,
    autoplay: {
      delay: 3000,
      disableOnInteraction: false,
    },
    speed: 800,
  });
</script>

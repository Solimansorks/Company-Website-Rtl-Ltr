<nav class="bg-white shadow-md sticky top-0 z-50" x-data="{ open: false }">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        {{-- Logo --}}
        <a href="{{ LaravelLocalization::localizeURL('/') }}">
            <img src="{{ asset('images/logo.png') }}" alt="We3ds Logo" class="h-10">
        </a>

        {{-- Mobile Menu Button --}}
        <button @click="open = !open" class="lg:hidden text-gray-700 focus:outline-none">
            <svg x-show="!open" xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                 viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
            <svg x-show="open" x-cloak xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                 viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M6 18L18 6M6 6l12 12"/>
            </svg>
        </button>

        {{-- Desktop Menu --}}
        <ul class="hidden lg:flex space-x-6 rtl:space-x-reverse font-medium text-gray-700">
            <li><a href="{{ LaravelLocalization::localizeURL('/') }}" class="hover:text-teal-600">{{ __('menu.home') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/about') }}" class="hover:text-teal-600">{{ __('menu.about') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/services') }}" class="hover:text-teal-600">{{ __('menu.services') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/portfolio') }}" class="hover:text-teal-600">{{ __('menu.portfolio') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/blog') }}" class="hover:text-teal-600">{{ __('menu.blog') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/contact') }}" class="hover:text-teal-600">{{ __('menu.contact') }}</a></li>
        </ul>

        {{-- Language Switcher (Desktop) --}}
        <div class="hidden lg:flex items-center space-x-2 rtl:space-x-reverse">
            @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                @if($localeCode != app()->getLocale())
                    <a rel="alternate" hreflang="{{ $localeCode }}"
                       href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}"
                       class="text-sm text-gray-600 hover:text-teal-600 uppercase">
                        {{ $localeCode }}
                    </a>
                @endif
            @endforeach
        </div>
    </div>

    {{-- Mobile Menu --}}
    <div x-show="open" x-cloak class="lg:hidden bg-white border-t border-gray-100 px-4 pb-4">
        <ul class="space-y-2 font-medium text-gray-700">
            <li><a href="{{ LaravelLocalization::localizeURL('/') }}" class="block py-2 hover:text-teal-600">{{ __('menu.home') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/about') }}" class="block py-2 hover:text-teal-600">{{ __('menu.about') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/services') }}" class="block py-2 hover:text-teal-600">{{ __('menu.services') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/portfolio') }}" class="block py-2 hover:text-teal-600">{{ __('menu.portfolio') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/blog') }}" class="block py-2 hover:text-teal-600">{{ __('menu.blog') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/contact') }}" class="block py-2 hover:text-teal-600">{{ __('menu.contact') }}</a></li>
        </ul>

        {{-- Language Switcher (Mobile) --}}
        <div class="mt-4">
            @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                @if($localeCode != app()->getLocale())
                    <a rel="alternate" hreflang="{{ $localeCode }}"
                       href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}"
                       class="text-sm text-gray-600 hover:text-teal-600 block py-1 uppercase">
                        {{ $localeCode }}
                    </a>
                @endif
            @endforeach
        </div>
    </div>
</nav>

<footer class="bg-gray-900 text-white py-12 mt-10">
    <div class="container mx-auto px-4 grid md:grid-cols-4 gap-8">
        
        {{-- 1. بيانات الشركة --}}
        <div>
            <h3 class="text-xl font-bold mb-4">{{ __('footer.company_info') }}</h3>
            <p class="mb-2">We3ds - Digital Solutions</p>
            <p class="mb-2">
                <i class="fas fa-envelope mr-2 text-blue-400"></i> solimanmohamed653.com
            </p>
            <p class="mb-2">
                <i class="fas fa-phone-alt mr-2 text-green-400"></i> +20 1004503896
            </p>
            <p class="mb-2">
                <i class="fas fa-map-marker-alt mr-2 text-red-400"></i> Egypt
            </p>
        </div>

        {{-- 2. روابط مهمة --}}
        <div>
            <h3 class="text-xl font-bold mb-4">{{ __('footer.useful_links') }}</h3>
            <ul class="space-y-2">
                <li><i class="fas fa-user mr-2 text-yellow-400"></i><a href="#" class="hover:underline">{{ __('footer.login') }}</a></li>
                <li><i class="fas fa-user-plus mr-2 text-yellow-400"></i><a href="#" class="hover:underline">{{ __('footer.register') }}</a></li>
                <li><i class="fas fa-briefcase mr-2 text-indigo-400"></i><a href="#" class="hover:underline">{{ __('footer.careers') }}</a></li>
                <li><i class="fas fa-headset mr-2 text-green-400"></i><a href="#" class="hover:underline">{{ __('footer.contact_us') }}</a></li>
            </ul>
        </div>

        {{-- 3. روابط إضافية --}}
        <div>
            <h3 class="text-xl font-bold mb-4">{{ __('footer.quick_links') }}</h3>
            <ul class="space-y-2">
                <li><i class="fas fa-shield-alt mr-2 text-pink-400"></i><a href="#" class="hover:underline">{{ __('footer.privacy_policy') }}</a></li>
                <li><i class="fas fa-info-circle mr-2 text-blue-400"></i><a href="{{ LaravelLocalization::localizeURL('/about') }}" class="hover:underline">{{ __('footer.about_us') }}</a></li>
                <li><i class="fas fa-virus mr-2 text-red-400"></i><a href="#" class="hover:underline">{{ __('footer.covid_updates') }}</a></li>
                <li><i class="fas fa-home mr-2 text-white"></i><a href="{{ LaravelLocalization::localizeURL('/') }}" class="hover:underline">{{ __('footer.home') }}</a></li>
            </ul>
        </div>

        {{-- 4. نبذة عن الشركة --}}
        <div>
            <h3 class="text-xl font-bold mb-4">{{ __('footer.about_we3ds') }}</h3>
            <p class="text-gray-300 mb-4">{{ __('footer.about_text') }}</p>
    <img src="{{ asset('images/logo/logo.jpeg') }}" alt="We3ds Logo" class="h-10">
        </div>
    </div>

    <div class="text-center mt-10 text-sm text-gray-500">
        © {{ date('Y') }} We3ds. {{ __('footer.rights') }}
    </div>
</footer>

<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>@yield('title', __('We3ds'))</title>

    {{-- Fonts --}}
    <link href="https://fonts.googleapis.com/css2?family=Almarai:wght@300;400;700&display=swap" rel="stylesheet" />

    {{-- Tailwind --}}
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />

    {{-- Font Awesome --}}
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />

    {{-- Swiper --}}
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    {{-- AOS --}}
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.4/dist/aos.css" />
    <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>

    {{-- AlpineJS --}}
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    {{-- Laravel Vite --}}
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        [x-cloak] { display: none !important; }

        body {
            font-family: 'Almarai', sans-serif !important;
        }
    </style>

    @stack('styles')
</head>

<body class="bg-gray-100 text-gray-800">

    {{-- Navbar --}}
    <nav class="bg-white shadow-md sticky top-0 z-50" x-data="{ open: false }">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
            {{-- Logo --}}
            <a href="{{ LaravelLocalization::localizeURL('/') }}">
                <img src="{{ asset('images/logo/logo.jpeg') }}" alt="We3ds Logo" class="h-10">
            </a>

            {{-- Hamburger --}}
            <button class="md:hidden text-gray-600 focus:outline-none" @click="open = !open">
                <i class="fas fa-bars text-xl"></i>
            </button>

            {{-- Desktop Menu --}}
            <ul class="hidden md:flex space-x-4 rtl:space-x-reverse font-medium text-gray-700">
                <li><a href="{{ LaravelLocalization::localizeURL('/') }}" class="hover:text-teal-600">{{ __('menu.home') }}</a></li>
                <li><a href="{{ LaravelLocalization::localizeURL('/about') }}" class="hover:text-teal-600">{{ __('menu.about') }}</a></li>
                <li><a href="{{ LaravelLocalization::localizeURL('/services') }}" class="hover:text-teal-600">{{ __('menu.services') }}</a></li>
                <li><a href="{{ LaravelLocalization::localizeURL('/portfolio') }}" class="hover:text-teal-600">{{ __('menu.portfolio') }}</a></li>
                <li><a href="{{ LaravelLocalization::localizeURL('/blog') }}" class="hover:text-teal-600">{{ __('menu.blog') }}</a></li>
                <li><a href="{{ LaravelLocalization::localizeURL('/contact') }}" class="hover:text-teal-600">{{ __('menu.contact') }}</a></li>
            </ul>

            {{-- Language Switch --}}
            <div class="hidden md:block">
                @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                    @if($localeCode != app()->getLocale())
                        <a href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}"
                           class="text-sm text-gray-600 hover:text-teal-600">
                            {{ strtoupper($localeCode) }}
                        </a>
                    @endif
                @endforeach
            </div>
        </div>

        {{-- Mobile Menu --}}
        <div class="md:hidden px-6 pb-4" x-show="open" x-cloak>
            <ul class="space-y-3 font-medium text-gray-700">
                <li><a href="{{ LaravelLocalization::localizeURL('/') }}">{{ __('menu.home') }}</a></li>
                <li><a href="{{ LaravelLocalization::localizeURL('/about') }}">{{ __('menu.about') }}</a></li>
                <li><a href="{{ LaravelLocalization::localizeURL('/services') }}">{{ __('menu.services') }}</a></li>
                <li><a href="{{ LaravelLocalization::localizeURL('/portfolio') }}">{{ __('menu.portfolio') }}</a></li>
                <li><a href="{{ LaravelLocalization::localizeURL('/blog') }}">{{ __('menu.blog') }}</a></li>
                <li><a href="{{ LaravelLocalization::localizeURL('/contact') }}">{{ __('menu.contact') }}</a></li>
                <li class="pt-2 border-t">
                    @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                        @if($localeCode != app()->getLocale())
                            <a href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}"
                               class="text-sm text-gray-600 hover:text-teal-600">
                                {{ strtoupper($localeCode) }}
                            </a>
                        @endif
                    @endforeach
                </li>
            </ul>
        </div>
    </nav>

    {{-- Page Content --}}
    <main class="py-10">
        <div class="container mx-auto px-4 lg:px-20">
            @yield('content')
        </div>
    </main>

    {{-- Footer --}}
    @include('layouts.partials.footer')

    {{-- AOS Init --}}
    <script>
        AOS.init({ duration: 800, once: true });
    </script>

    {{-- Swiper --}}
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            new Swiper(".heroSwiper", {
                direction: "vertical",
                loop: true,
                pagination: { el: ".swiper-pagination", clickable: true },
                navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" },
            });
        });
    </script>

    @stack('scripts')
</body>
</html>

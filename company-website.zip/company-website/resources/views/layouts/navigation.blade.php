<nav class="bg-white shadow-md">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">
        <a href="{{ LaravelLocalization::localizeURL('/') }}" class="text-xl font-bold text-teal-600">We3ds</a>

        <ul class="flex space-x-4 rtl:space-x-reverse">
            <li><a href="{{ LaravelLocalization::localizeURL('/') }}" class="hover:text-teal-600">{{ __('menu.home') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/about') }}" class="hover:text-teal-600">{{ __('menu.about') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/services') }}" class="hover:text-teal-600">{{ __('menu.services') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/portfolio') }}" class="hover:text-teal-600">{{ __('menu.portfolio') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/blog') }}" class="hover:text-teal-600">{{ __('menu.blog') }}</a></li>
            <li><a href="{{ LaravelLocalization::localizeURL('/contact') }}" class="hover:text-teal-600">{{ __('menu.contact') }}</a></li>
        </ul>

        {{-- Language Switcher --}}
        <div>
            @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                @if($localeCode != app()->getLocale())
                    <a rel="alternate" hreflang="{{ $localeCode }}" href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}"
                       class="text-sm text-gray-600 hover:text-teal-600">
                        {{ strtoupper($localeCode) }}
                    </a>
                @endif
            @endforeach
        </div>
    </div>
</nav>

<?php

return [
    'Login' => 'Login',
    'Register' => 'Register',
    'Logout' => 'Logout',
    'E-Mail Address' => 'E-Mail Address',
    'Email Address' => 'Email Address',
    'Password' => 'Password',
    'Remember Me' => 'Remember Me',
    'Forgot Your Password?' => 'Forgot Your Password?',
    'Confirm Password' => 'Confirm Password',
    'Name' => 'Name',
    'Reset Password' => 'Reset Password',
    'Send Password Reset Link' => 'Send Password Reset Link',
];

<?php

return [
    'page_title' => 'Our Services',
    'our_services' => 'Our Services',
    'intro' => 'We provide a complete range of digital services to help your business thrive online.',

    'items' => [
        [
            'icon' => '💻',
            'title' => 'Web Development',
            'description' => 'Designing and developing professional, responsive websites.'
        ],
        [
            'icon' => '📱',
            'title' => 'Mobile Apps',
            'description' => 'High-quality Android and iOS app development.'
        ],
        [
            'icon' => '🎨',
            'title' => 'Graphic Design',
            'description' => 'Creative logos, branding, and social media designs.'
        ],
        [
            'icon' => '📣',
            'title' => 'Digital Marketing',
            'description' => 'Ad campaigns, content planning, and performance analytics.'
        ],
        [
            'icon' => '🛒',
            'title' => 'E-commerce',
            'description' => 'Professional online stores to sell your products and services.'
        ],
        [
            'icon' => '⚙️',
            'title' => 'Digital Transformation',
            'description' => 'Technical solutions to digitize your business and increase efficiency.'
        ],
    ]
];

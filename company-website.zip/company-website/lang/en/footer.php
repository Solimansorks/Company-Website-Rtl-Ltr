<?php

return [
    'company_info'    => 'Company Info',
    'useful_links'    => 'Useful Links',
    'login'           => 'Login',
    'register'        => 'Register',
    'careers'         => 'Careers',
    'contact_us'      => 'Contact Us',
    'quick_links'     => 'Quick Links',
    'privacy_policy'  => 'Privacy Policy',
    'about_us'        => 'About Us',
    'covid_updates'   => 'COVID-19 Updates',
    'home'            => 'Home',
    'about_we3ds'     => 'About We3ds',
    'about_text'      => 'We3ds is a creative digital agency offering web, mobile, and branding solutions.',
    'rights'          => 'All rights reserved.',
];

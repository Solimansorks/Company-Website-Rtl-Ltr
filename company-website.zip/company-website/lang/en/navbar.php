<?php

return [
    'home' => 'Home',
    'about' => 'About Us',
    'services' => 'Services',
    'web' => 'Web Development',
    'mobile' => 'Mobile Apps',
    'graphic' => 'Graphic Design',
    'visual' => '3D Visualization',
    'social' => 'Social Media',
    'ecommerce' => 'E-Commerce',
    'portfolio' => 'Portfolio',
    'testimonials' => 'Testimonials',
    'contact' => 'Contact',
    'blog' => 'Blog',
];

<?php
return [
    'hero_title' => 'Welcome to Our Company',
    'hero_subtitle' => 'We provide the best solutions for your business.',
    'hero_button' => 'Contact Us',

    'about_title' => 'About Us',
    'about_text' => 'We are a team of passionate professionals dedicated to delivering quality services.',

    'services_title' => 'Our Services',
    'services_web' => 'Web Development',
    'services_mobile' => 'Mobile Applications',
    'services_graphic' => 'Graphic Design',
    'services_visual' => 'Visual Identity',
    'services_social' => 'Social Media Management',
    'services_ecommerce' => 'E-commerce Solutions',

    'portfolio_title' => 'Our Portfolio',
    'portfolio_subtitle' => 'Check out some of our recent projects.',

    'testimonials_title' => 'Testimonials',
    'testimonials_subtitle' => 'What our clients say about us.',

    'contact_title' => 'Get In Touch',
    'contact_subtitle' => 'We are here to answer your questions and help you.',
    'contact_button' => 'Send a Message',
];

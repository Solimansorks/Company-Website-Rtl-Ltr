<?php

return [
    'home' => 'Home',
    'about' => 'About Us',
    'services' => 'Our Services',
    'portfolio' => 'Portfolio',
    'testimonials' => 'Testimonials',
    'contact' => 'Contact Us',
    'blog' => 'Blog',
];

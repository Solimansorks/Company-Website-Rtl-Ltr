<?php

return [
    'title' => 'Contact Us',
    'subtitle' => 'We’d love to hear from you. Fill out the form and we’ll get back to you soon.',
    'name' => 'Your Name',
    'email' => 'Your Email',
    'phone' => 'Phone Number',
    'message' => 'Your Message',
    'send' => 'Send Message',
    'success' => 'Your message has been sent successfully!',
    'error' => 'Something went wrong. Please try again later.',
    'address' => 'Our Location',
    'contact_details' => 'Contact Details',
    'working_hours' => 'Working Hours',
    'hours_value' => 'Sunday to Thursday, 9AM - 5PM',
];

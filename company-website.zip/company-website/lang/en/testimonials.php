<?php

return [
    'title' => 'What Our Clients Say',
    'subtitle' => 'We value every word our clients say about us.',
    'items' => [
        [
            'name' => 'John Smith',
            'position' => 'CEO, TechCorp',
            'message' => 'Great experience working with the team. They delivered on time with high quality!',
        ],
        [
            'name' => 'Sarah Johnson',
            'position' => 'Marketing Director',
            'message' => 'Excellent communication and attention to detail. Highly recommended!',
        ],
        [
            'name' => 'Ahmed Ali',
            'position' => 'Entrepreneur',
            'message' => 'Very professional and skilled. Helped me bring my ideas to life.',
        ],
    ],
];

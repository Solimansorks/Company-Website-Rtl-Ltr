<?php

return [
    'about' => [
        'page_title' => 'About Us',
        'title' => 'WE3DS IT Company',
        'description' => 'We specialize in delivering complete digital solutions...',
        'years_experience' => 'Years of Experience',
        'projects' => 'Successful Projects',
        'clients' => 'Happy Clients',
        'team' => 'Team Members',
        'more_title' => 'Why Choose WE3DS?',
        'more_content' => "
            <p>We provide integrated solutions starting from stunning design to advanced development.</p>
            <p>Our expert team brings your ideas to life with precision and quality assurance.</p>
            <p>We strive for client satisfaction by offering continuous support and tailored market-ready strategies.</p>
        ",
    ],
];

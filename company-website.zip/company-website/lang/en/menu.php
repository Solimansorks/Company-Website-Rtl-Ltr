<?php
return [
    'home' => 'Home',
    'about' => 'About Us',
    'services' => 'Services',
    'portfolio' => 'Portfolio',
    'blog' => 'Blog',
    'contact' => 'Contact',
];

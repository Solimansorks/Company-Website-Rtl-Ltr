<?php

return [
    'home' => 'Home',
    'about' => 'About Us',
    'services' => 'Our Services',
    'portfolio' => 'Portfolio',
    'testimonials' => 'Testimonials',
    'contact' => 'Contact Us',
    'blog' => 'Blog',
    'rights' => 'All rights reserved',
    'developed_by' => 'Developed by',
    'quick_links' => 'Quick Links',
    'get_in_touch' => 'Get in Touch',
    'address' => 'Address',
    'phone' => 'Phone',
    'email' => 'Email',
    'location' => 'Nasr City, Cairo, Egypt',
];

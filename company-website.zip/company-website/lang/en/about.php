<?php

return [
    'page_title'       => 'About Us',
    'title'            => 'Who We Are',
    'description'      => 'We are a leading company in web development and design.',
    'years_experience' => 'Years of Experience',
    'projects'         => 'Completed Projects',
    'clients'          => 'Happy Clients',
    'team'             => 'Team Members',
    'more_title'       => 'Why Choose Us?',
    'more_content'     => '<p>We excel in innovation, quality, and complete client satisfaction.</p>
<p>Our team includes top developers and designers with high expertise.</p>
<p>We use the latest technologies to deliver the best solutions to our clients.</p>',
];

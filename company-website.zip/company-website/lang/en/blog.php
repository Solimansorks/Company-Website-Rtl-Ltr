<?php
return [
    'title' => 'Our Blog',
];

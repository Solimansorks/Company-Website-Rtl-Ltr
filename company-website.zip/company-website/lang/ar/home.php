<?php
return [
    'hero_title' => 'مرحبا بكم في شركتنا',
    'hero_subtitle' => 'نقدم أفضل الحلول لأعمالك.',
    'hero_button' => 'اتصل بنا',

    'about_title' => 'من نحن',
    'about_text' => 'نحن فريق من المحترفين الشغوفين ملتزمون بتقديم خدمات عالية الجودة.',

    'services_title' => 'خدماتنا',
    'services_web' => 'تطوير الويب',
    'services_mobile' => 'تطبيقات الجوال',
    'services_graphic' => 'تصميم الجرافيك',
    'services_visual' => 'الهوية البصرية',
    'services_social' => 'إدارة وسائل التواصل الاجتماعي',
    'services_ecommerce' => 'حلول التجارة الإلكترونية',

    'portfolio_title' => 'أعمالنا',
    'portfolio_subtitle' => 'اطلع على بعض مشاريعنا الأخيرة.',

    'testimonials_title' => 'آراء العملاء',
    'testimonials_subtitle' => 'ماذا يقول عملاؤنا عنا.',

    'contact_title' => 'تواصل معنا',
    'contact_subtitle' => 'نحن هنا للرد على استفساراتك ومساعدتك.',
    'contact_button' => 'أرسل رسالة',
];

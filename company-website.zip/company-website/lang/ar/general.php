<?php

return [
    'home' => 'الرئيسية',
    'about' => 'من نحن',
    'services' => 'خدماتنا',
    'portfolio' => 'أعمالنا',
    'testimonials' => 'آراء العملاء',
    'contact' => 'اتصل بنا',
    'blog' => 'المدونة',
    'rights' => 'جميع الحقوق محفوظة',
    'developed_by' => 'تم التطوير بواسطة',
    'quick_links' => 'روابط سريعة',
    'get_in_touch' => 'تواصل معنا',
    'address' => 'العنوان',
    'phone' => 'رقم الهاتف',
    'email' => 'البريد الإلكتروني',
    'location' => 'مدينة نصر، القاهرة، مصر',
];

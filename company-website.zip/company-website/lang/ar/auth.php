<?php

return [
    'login' => 'تسجيل الدخول',
    'email' => 'البريد الإلكتروني',
    'password' => 'كلمة المرور',
    'remember_me' => 'تذكرني',
    'forgot_password' => 'هل نسيت كلمة المرور؟',
];

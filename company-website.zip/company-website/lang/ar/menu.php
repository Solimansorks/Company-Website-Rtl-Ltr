<?php
return [
    'home' => 'الرئيسية',
    'about' => 'من نحن',
    'services' => 'خدماتنا',
    'portfolio' => 'أعمالنا',
    'blog' => 'المدونة',
    'contact' => 'اتصل بنا',
];

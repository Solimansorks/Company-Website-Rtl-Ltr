<?php

return [
    'home' => 'الرئيسية',
    'about' => 'من نحن',
    'services' => 'خدماتنا',
    'portfolio' => 'معرض الأعمال',
    'testimonials' => 'آراء العملاء',
    'contact' => 'تواصل معنا',
    'blog' => 'المدونة',
];

<?php

return [
    'company_info'    => 'معلومات الشركة',
    'useful_links'    => 'روابط مهمة',
    'login'           => 'تسجيل الدخول',
    'register'        => 'إنشاء حساب',
    'careers'         => 'وظائف',
    'contact_us'      => 'تواصل معنا',
    'quick_links'     => 'روابط سريعة',
    'privacy_policy'  => 'سياسة الخصوصية',
    'about_us'        => 'من نحن',
    'covid_updates'   => 'تحديثات كوفيد-19',
    'home'            => 'الرئيسية',
    'about_we3ds'     => 'نبذة عن We3ds',
    'about_text'      => 'We3ds هي وكالة رقمية مبتكرة تقدم حلولاً لتطوير المواقع والتطبيقات والهوية.',
    'rights'          => 'جميع الحقوق محفوظة.',
];

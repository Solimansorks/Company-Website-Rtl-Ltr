<?php
return [
    'title' => 'مدونتنا',
];

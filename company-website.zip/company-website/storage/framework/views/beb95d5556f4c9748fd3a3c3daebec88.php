<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo $__env->yieldContent('title', __('We3ds')); ?></title>

    
    <link href="https://fonts.googleapis.com/css2?family=Almarai:wght@300;400;700&display=swap" rel="stylesheet" />

    
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />

    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.4/dist/aos.css" />
    <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>

    
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        [x-cloak] { display: none !important; }

        body {
            font-family: 'Almarai', sans-serif !important;
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="bg-gray-100 text-gray-800">

    
    <nav class="bg-white shadow-md sticky top-0 z-50" x-data="{ open: false }">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
            
            <a href="<?php echo e(LaravelLocalization::localizeURL('/')); ?>">
                <img src="<?php echo e(asset('images/logo/logo.jpeg')); ?>" alt="We3ds Logo" class="h-10">
            </a>

            
            <button class="md:hidden text-gray-600 focus:outline-none" @click="open = !open">
                <i class="fas fa-bars text-xl"></i>
            </button>

            
            <ul class="hidden md:flex space-x-4 rtl:space-x-reverse font-medium text-gray-700">
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/')); ?>" class="hover:text-teal-600"><?php echo e(__('menu.home')); ?></a></li>
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/about')); ?>" class="hover:text-teal-600"><?php echo e(__('menu.about')); ?></a></li>
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/services')); ?>" class="hover:text-teal-600"><?php echo e(__('menu.services')); ?></a></li>
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/portfolio')); ?>" class="hover:text-teal-600"><?php echo e(__('menu.portfolio')); ?></a></li>
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/blog')); ?>" class="hover:text-teal-600"><?php echo e(__('menu.blog')); ?></a></li>
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/contact')); ?>" class="hover:text-teal-600"><?php echo e(__('menu.contact')); ?></a></li>
            </ul>

            
            <div class="hidden md:block">
                <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($localeCode != app()->getLocale()): ?>
                        <a href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>"
                           class="text-sm text-gray-600 hover:text-teal-600">
                            <?php echo e(strtoupper($localeCode)); ?>

                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div class="md:hidden px-6 pb-4" x-show="open" x-cloak>
            <ul class="space-y-3 font-medium text-gray-700">
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/')); ?>"><?php echo e(__('menu.home')); ?></a></li>
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/about')); ?>"><?php echo e(__('menu.about')); ?></a></li>
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/services')); ?>"><?php echo e(__('menu.services')); ?></a></li>
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/portfolio')); ?>"><?php echo e(__('menu.portfolio')); ?></a></li>
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/blog')); ?>"><?php echo e(__('menu.blog')); ?></a></li>
                <li><a href="<?php echo e(LaravelLocalization::localizeURL('/contact')); ?>"><?php echo e(__('menu.contact')); ?></a></li>
                <li class="pt-2 border-t">
                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($localeCode != app()->getLocale()): ?>
                            <a href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>"
                               class="text-sm text-gray-600 hover:text-teal-600">
                                <?php echo e(strtoupper($localeCode)); ?>

                            </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </li>
            </ul>
        </div>
    </nav>

    
    <main class="py-10">
        <div class="container mx-auto px-4 lg:px-20">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    
    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <script>
        AOS.init({ duration: 800, once: true });
    </script>

    
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            new Swiper(".heroSwiper", {
                direction: "vertical",
                loop: true,
                pagination: { el: ".swiper-pagination", clickable: true },
                navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" },
            });
        });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH E:\شغل بورتفوليو\companysite\company-website\resources\views/layouts/app.blade.php ENDPATH**/ ?>
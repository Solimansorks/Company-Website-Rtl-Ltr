

<?php $__env->startSection('title', __('custom::about.page_title')); ?>

<?php $__env->startSection('content'); ?>

    
    <section class="py-20 bg-gray-100" id="about">
        <div class="container mx-auto px-4">
            <div class="md:flex md:items-center md:justify-between gap-10">
                
                
                <div class="md:w-1/2 mb-10 md:mb-0">
                    <h2 class="text-4xl font-bold text-blue-800 mb-4 animate-fade-in">
                        <?php echo e(__('custom::about.title')); ?>

                    </h2>
                    <p class="text-gray-700 text-lg leading-relaxed mb-6 animate-fade-in">
                        <?php echo e(__('custom::about.description')); ?>

                    </p>
                    <div class="grid grid-cols-2 gap-6 animate-fade-in">
                        <div>
                            <p class="text-3xl font-bold text-blue-600">+10</p>
                            <p class="text-gray-600"><?php echo e(__('custom::about.years_experience')); ?></p>
                        </div>
                        <div>
                            <p class="text-3xl font-bold text-blue-600">+120</p>
                            <p class="text-gray-600"><?php echo e(__('custom::about.projects')); ?></p>
                        </div>
                        <div>
                            <p class="text-3xl font-bold text-blue-600">+50</p>
                            <p class="text-gray-600"><?php echo e(__('custom::about.clients')); ?></p>
                        </div>
                        <div>
                            <p class="text-3xl font-bold text-blue-600">+15</p>
                            <p class="text-gray-600"><?php echo e(__('custom::about.team')); ?></p>
                        </div>
                    </div>
                </div>

                
                <div class="md:w-1/2 text-center">
                    <img src="<?php echo e(asset('/images/slides/slide2.jpg')); ?>" alt="About Us" class="rounded-lg shadow-lg w-full max-w-md mx-auto">
                </div>
            </div>
        </div>
            
    <section class="bg-white py-12 mt-10">
        <div class="container mx-auto px-4 max-w-4xl">
            <h3 class="text-2xl font-semibold text-blue-800 mb-6 text-center">
                <?php echo e(__('custom::about.more_title')); ?>

            </h3>
            <div class="text-gray-700 text-lg leading-relaxed space-y-4">
                <?php echo __('custom::about.more_content'); ?>

            </div>
        </div>
    </section>
    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\شغل بورتفوليو\companysite\company-website\resources\views/pages/about.blade.php ENDPATH**/ ?>
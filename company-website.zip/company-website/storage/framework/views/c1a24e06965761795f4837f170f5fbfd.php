

<?php $__env->startSection('title', __('services.page_title')); ?>

<?php $__env->startSection('content'); ?>
<section class="bg-gray-100 py-16">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-4 text-blue-600 animate-fade-in">
            <?php echo e(__('services.our_services')); ?>

        </h2>
        <p class="text-gray-600 max-w-xl mx-auto mb-10 animate-fade-in">
            <?php echo e(__('services.intro')); ?>

        </p>

        <div class="grid gap-8 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            <?php $__currentLoopData = __('services.items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-xl shadow-md p-6 hover:shadow-xl transition duration-300 animate-slide-up text-start">
                    <div class="text-5xl mb-4 text-blue-500">
                        <?php echo $service['icon']; ?>

                    </div>
                    <h3 class="text-xl font-bold mb-2 text-gray-800">
                        <?php echo e($service['title']); ?>

                    </h3>
                    <p class="text-gray-600 text-sm leading-relaxed">
                        <?php echo e($service['description']); ?>

                    </p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\شغل بورتفوليو\companysite\company-website\resources\views/pages/services.blade.php ENDPATH**/ ?>